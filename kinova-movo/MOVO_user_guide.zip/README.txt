MOVO User Guide - Instructions

1. Extract contents of zip file to local folder
2. Open index.html