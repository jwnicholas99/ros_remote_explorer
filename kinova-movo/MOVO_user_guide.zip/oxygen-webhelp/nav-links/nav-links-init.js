/* Load the navigation links library. */
requirejs(['nav-links-loader']);